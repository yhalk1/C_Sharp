﻿using System;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercise 1:
            // Move the Data Models namely Student.cs and Course.cs to new class library CMS.Data.Models.dll
            // Add this reference to LinqToEntities console application. 

            // Exercise 2:
            // Move CMS.db outside the LinqToEntities folder so that it can be referred by other applications. 

            // Exercise 3:
            // Update LinqToEntities application to reflect the above changes.             
        }
    }
}
