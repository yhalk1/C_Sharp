﻿using System;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercise 1:
            // Write a simple C# program to declare a list of integer numbers, 
            // followed by writing queries using both query and method syntax 
            // to calculate their square (num * num), and finally print them to the console.

            // Step 1: Getting data source


            // Query syntax
            // Step 2: Writing query 
            // Step 3: Executing query 


            // Method syntax
            // Step 2: Writing query 
            // Step 3: Executing query 

            
        }
    }
}
