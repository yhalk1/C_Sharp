﻿using System;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercise 1:
            // Write a simple C# program to declare a list of integer values,
            // followed by a simple LINQ query to check for even numbers, 
            // and finally print them to the console.
            // NOTE: You may refer to the sample program we used before for 
            //       reference.

            // Step 1: Getting data source


            // Step 2: Writing query
                // Part 1: Data source
                // Part 2: Filter    
                // Part 3: Select

            // Step 3: Executing query
            
        }
    }
}
